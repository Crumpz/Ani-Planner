//
//  QuoteView.swift
//  AnimeProductivityApp
//
//  Created by Sudowe, Yuki - Student on 10/24/24.
//

import SwiftUI

// QuoteView for displaying quotes
struct QuoteView: View {
    @State private var currentQuote: String = ""
    var quotes = [
        "The future belongs to those who believe in the beauty of their dreams.",
        "To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment.",
        "Life is either a daring adventure or nothing at all.",
        "Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.",
        "In the end, we will remember not the words of our enemies, but the silence of our friends."
    ]
    
    var body: some View {
        VStack {
            Text("Daily Quotes")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            
            // Display the current quote
            Text("“\(currentQuote)”")
                .font(.title3)
                .fontWeight(.semibold)
                .padding()
                .background(Color.purple.opacity(0.1))
                .cornerRadius(12)
                .padding(.horizontal)
            
            // Button to generate a new quote
            Button(action: {
                getRandomQuote() // Call function to get a new quote
                SoundManager.shared.playPopSound() // Play sound on tap
            }) {
                Text("Get Random Quote")
                    .font(.title2)
                    .padding()
                    .background(Color.purple)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .shadow(radius: 5)
            }
            .padding(.top)
            
            Spacer()
        }
        .padding()
        .background(Color(.systemGray6))
        .navigationTitle("Quotes")
        .onAppear {
            getRandomQuote() // Get an initial quote when the view appears
        }
    }
    
    // Function to get a random quote
    private func getRandomQuote() {
        currentQuote = quotes.randomElement() ?? "No quotes available."
    }
}



#Preview {
    QuoteView()
}
