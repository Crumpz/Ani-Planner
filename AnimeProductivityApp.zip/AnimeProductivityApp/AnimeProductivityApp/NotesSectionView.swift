//
//  NotesSectionView.swift
//  AnimeProductivityApp
//
//  Created by Sudowe, Yuki - Student on 10/24/24.
//

import SwiftUI
import AVFoundation

struct NotesView: View {
    
    
    @State private var notes: [String] = ["Remember to draw your waifu!", "Don't forget your training schedule"]
    @State private var newNote: String = ""
    
    var body: some View {
        VStack {
            HStack {
                TextField("Add a new note", text: $newNote)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Button(action: {
                    if !newNote.isEmpty {
                        notes.append(newNote)
                        newNote = ""
                    }
                }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title)
                        .foregroundColor(.purple)
                }
            }
            .padding()
            .background(Color.green.opacity(0.1))
            .cornerRadius(12)
            
            List {
                ForEach(notes, id: \.self) { note in
                    Text(note)
                }
            }
        }
        .padding()
        .navigationTitle("Anime Notes")
        .background(Color(.systemGray6)) // Clean and consistent
        .onAppear() {
            let uploadedTasks = UserDefaults.standard.stringArray(forKey: "notes")
            //            tasks.append(contentsOf: uploadedTasks)
            notes = uploadedTasks ?? ["Remember to draw your waifu!", "Don't forget your training schedule"]
        }
        .onDisappear() {
            UserDefaults.standard.set(notes, forKey: "notes")
        }
    }
}

struct NotesView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            NotesView()
        }
    }
}
