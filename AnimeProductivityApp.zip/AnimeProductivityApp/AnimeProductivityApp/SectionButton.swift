//
//  SectionButton.swift
//  AnimeProductivityApp
//
//  Created by Sudowe, Yuki - Student on 10/24/24.
//

import SwiftUI
import AVFoundation

struct SectionButton: View {
    var title: String
    var image: String
    var color: Color
    var backgroundColor: Color
    
    var body: some View {
        HStack {
            Image(systemName: image)
                .font(.title)
                .foregroundColor(color)
            Text(title)
                .font(.headline)
                .fontWeight(.bold)
                .foregroundColor(color)
            Spacer()
        }
        .padding()
        .background(backgroundColor)
        .cornerRadius(12)
        .shadow(color: color.opacity(0.3), radius: 5, x: 0, y: 5)
    }
}


struct SectionButton_Previews: PreviewProvider {
    static var previews: some View {
        SectionButton(
            title: "Tasks",
            image: "checkmark.circle",
            color: .blue,
            backgroundColor: .purple.opacity(0.1)
        )
        .previewLayout(.sizeThatFits) // Ensures the button is shown in a fitting size
        .padding() // Adds padding around the button in the preview
    }
}
