//
//  ContentView.swift
//  AnimeProductivityApp
//
//  Created by Sudowe, Yuki - Student on 10/24/24.
//

import SwiftUI
import AVFoundation

struct HomeView: View {
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    Spacer()
                    Text("Welcome, Senpai!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.purple)
                        .padding(.top, 20)
                    
                    Image("anime-chibi") // Ensure this image is in your asset catalog
                        .resizable()
                        .scaledToFit()
                        .frame(height: 150)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.purple.opacity(0.7), lineWidth: 4))
                        .shadow(radius: 5)
                    
                    Text("“Your limits are defined only by your mind, Senpai!”")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(.black)
                        .padding()
                        .background(Color.purple.opacity(0.1))
                        .cornerRadius(12)
                    
                    // Button to navigate to the Menu View
                    NavigationLink(destination: MenuView()) {
                        Text("Access Your Planner")
                            .font(.title2)
                            .fontWeight(.bold)
                            .padding()
                            .background(Color.purple)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                            .shadow(radius: 5)
                    }
                    .buttonStyle(PlainButtonStyle())
                    .onTapGesture {
                        SoundManager.shared.playPopSound() // Play sound on tap
                    }
                    
                    Spacer()
                }
                
            }
            .navigationTitle("My Anime Planner")
            .padding()
            .background(Color(.systemGray6))
            
        }
    }
}


struct MenuView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Select Your Task")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.purple)
                .padding(.top)
            
            NavigationLink(destination: TaskView()) {
                SectionButton(title: "Tasks", image: "checkmark.circle", color: .blue, backgroundColor: .purple.opacity(0.1))
            }
            .buttonStyle(PlainButtonStyle())
            .onTapGesture {
                SoundManager.shared.playPopSound()
            }
            
            NavigationLink(destination: NotesView()) {
                SectionButton(title: "Notes", image: "pencil.circle", color: .green, backgroundColor: .purple.opacity(0.1))
            }
            .buttonStyle(PlainButtonStyle())
            .onTapGesture {
                SoundManager.shared.playPopSound()
            }
            
            NavigationLink(destination: CalendarView()) {
                SectionButton(title: "Calendar", image: "calendar.circle", color: .red, backgroundColor: .purple.opacity(0.1))
            }
            .buttonStyle(PlainButtonStyle())
            .onTapGesture {
                SoundManager.shared.playPopSound()
            }
            
            NavigationLink(destination: TimerView()) {
                SectionButton(title: "Pomodoro Timer", image: "timer", color: .orange, backgroundColor: .purple.opacity(0.1))
            }
            .buttonStyle(PlainButtonStyle())
            .onTapGesture {
                SoundManager.shared.playPopSound()
            }
            
            NavigationLink(destination: QuoteView()) {
                SectionButton(title: "Daily Quotes", image: "quote.bubble", color: .yellow, backgroundColor: .purple.opacity(0.1))
            }
            .buttonStyle(PlainButtonStyle())
            .onTapGesture {
                SoundManager.shared.playPopSound()
            }
            
            NavigationLink(destination: PlannerView()) {
                SectionButton(title: "Planner", image: "doc.plain", color: .pink, backgroundColor: .purple.opacity(0.1))
            }
            .buttonStyle(PlainButtonStyle())
            .onTapGesture {
                SoundManager.shared.playPopSound()
            }
            
            Spacer()
        }
        .padding()
        .background(Color(.systemGray6))
        .navigationTitle("Menu")
    }
}




struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}


