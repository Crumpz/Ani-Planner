//
//  TaskSectionView.swift
//  AnimeProductivityApp
//
//  Created by Sudowe, Yuki - Student on 10/24/24.
//

import SwiftUI

// Task Management Page
struct TaskView: View {
    @State private var tasks: [String] = ["Defeat your homework boss", "Prepare for the exam battle"]
    @State private var newTask: String = ""
    
    var body: some View {
        VStack {
            HStack {
                TextField("Add a new task", text: $newTask)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                Button(action: {
                    if !newTask.isEmpty {
                        tasks.append(newTask)
                        newTask = ""
                    }
                }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title)
                        .foregroundColor(.purple)
                }
            }
            .padding()
            .background(Color.blue.opacity(0.1))
            .cornerRadius(12)
            
            List {
                ForEach(tasks, id: \.self) { task in
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.purple)
                        Text(task)
                    }
                }
                
            }
        }
        .padding()
        .navigationTitle("Anime Tasks")
        .background(Color(.systemGray6)) // Softer background
        .onAppear() {
            let uploadedTasks = UserDefaults.standard.stringArray(forKey: "tasks")
//            tasks.append(contentsOf: uploadedTasks)
            tasks = uploadedTasks ?? ["Defeat your homework boss", "Prepare for the exam battle"]
        }
        .onDisappear() {
            UserDefaults.standard.set(tasks, forKey: "tasks")
        }
    }
}





struct TaskView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            TaskView()
        }
    }
}
