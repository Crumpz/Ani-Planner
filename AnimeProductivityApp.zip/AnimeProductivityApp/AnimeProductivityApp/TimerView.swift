//
//  TimerView.swift
//  AnimeProductivityApp
//
//  Created by Sudowe, Yuki - Student on 10/24/24.
//

import SwiftUI

struct TimerView: View {
    @State private var timer: Timer?
    @State private var timeRemaining: Int = 1500 // 25 minutes
    @State private var isTimerRunning = false
    
    var body: some View {
        VStack {
            Text("Pomodoro Timer")
                .font(.headline)
                .fontWeight(.bold)
                .padding(.top)
            
            Text(timeString(from: timeRemaining))
                .font(.system(size: 48, weight: .bold))
                .padding()
                .background(Color.white.opacity(0.2))
                .cornerRadius(10)
                .padding()
                .foregroundColor(.black)
            
            HStack {
                Button(action: {
                    if isTimerRunning {
                        pauseTimer()
                    } else {
                        startTimer()
                    }
                    isTimerRunning.toggle()
                    SoundManager.shared.playPopSound() // Play sound on button press
                }) {
                    Text(isTimerRunning ? "Pause" : "Start")
                        .font(.title2)
                        .padding()
                        .background(isTimerRunning ? Color.orange : Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
                }
                
                Button(action: resetTimer) {
                    Text("Reset")
                        .font(.title2)
                        .padding()
                        .background(Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
                }
            }
            .padding(.top)
            
            Spacer()
        }
        .padding()
        .onDisappear {
            timer?.invalidate() // Stop the timer if the view disappears
        }
    }
    
    // Start the timer
    private func startTimer() {
        timer?.invalidate() // Invalidate any existing timer
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
            } else {
                timer?.invalidate()
                isTimerRunning = false // Stop the timer
                SoundManager.shared.playPopSound() // Play sound on completion
            }
        }
    }
    
    // Pause the timer
    private func pauseTimer() {
        timer?.invalidate()
    }
    
    // Reset the timer
    private func resetTimer() {
        timer?.invalidate()
        timeRemaining = 1500 // Reset to 25 minutes
        isTimerRunning = false
    }
    
    // Convert time remaining to a string for display
    private func timeString(from seconds: Int) -> String {
        let minutes = seconds / 60
        let seconds = seconds % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}



#Preview {
    TimerView()
}
