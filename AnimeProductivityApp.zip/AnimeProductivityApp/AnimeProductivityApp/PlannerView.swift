//
//  PlannerView.swift
//  AnimeProductivityApp
//
//  Created by Sudowe, Yuki - Student on 10/24/24.
//

import SwiftUI

import SwiftUI

struct PlannerView: View {
    @State private var activities: [String] = []
    @State private var newActivity: String = ""
    
    var body: some View {
        VStack {
            Text("Daily Planner")
                .font(.headline)
                .fontWeight(.bold)
                .padding(.top)
            
            HStack {
                TextField("Add Activity", text: $newActivity)
                    .padding()
                    .background(Color.white.opacity(0.2))
                    .cornerRadius(10)
                
                Button("Add") {
                    if !newActivity.isEmpty {
                        activities.append(newActivity)
                        newActivity = ""
                        SoundManager.shared.playPopSound() // Play sound on button press
                    }
                }
                .padding()
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 5)
            }
            .padding()
            
            List {
                ForEach(activities, id: \.self) { activity in
                    Text(activity)
                        .padding()
                        .background(Color.white.opacity(0.1))
                        .cornerRadius(10)
                        .shadow(color: Color.black.opacity(0.2), radius: 3, x: 0, y: 3)
                }
                .onDelete(perform: deleteActivity)
            }
            .listStyle(PlainListStyle())
            .padding(.bottom)
        }
        .padding()
    }
    
    private func deleteActivity(at offsets: IndexSet) {
        activities.remove(atOffsets: offsets)
    }
}


#Preview {
    PlannerView()
}
