//
//  CalendarSectionView.swift
//  AnimeProductivityApp
//
//  Created by Sudowe, Yuki - Student on 10/24/24.
//

import SwiftUI

struct CalendarView: View {
    @State private var selectedDate = Date()
    @State private var reminders: [String] = []
    @State private var newReminderText = ""
    
    var body: some View {
        VStack {
            // DatePicker to select the date
            DatePicker("Select Date", selection: $selectedDate, displayedComponents: .date)
                .datePickerStyle(GraphicalDatePickerStyle())
                .onChange(of: selectedDate) {
                    loadReminders(for: selectedDate)
                }
            
            // List of reminders for the selected date
            List {
                ForEach(reminders, id: \.self) { reminder in
                    Text(reminder)
                }
                .onDelete(perform: deleteReminder)
            }
            
            // New reminder input and add button
            HStack {
                TextField("New Reminder", text: $newReminderText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button(action: addReminder) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title)
                        .foregroundColor(.blue)
                }
            }
            .padding()
        }
        .onAppear {
            loadReminders(for: selectedDate)
        }
        .navigationTitle("Calendar")
    }
    
    // Adds a new reminder and saves it
    private func addReminder() {
        guard !newReminderText.isEmpty else { return }
        reminders.append(newReminderText)
        saveReminders(for: selectedDate)
        newReminderText = ""
    }
    
    // Deletes a reminder and saves the updated list
    private func deleteReminder(at offsets: IndexSet) {
        reminders.remove(atOffsets: offsets)
        saveReminders(for: selectedDate)
    }
    
    // Saves reminders for the specific date to UserDefaults
    private func saveReminders(for date: Date) {
        let dateKey = formattedDate(for: date)
        UserDefaults.standard.set(reminders, forKey: dateKey)
    }
    
    // Loads reminders for a specific date from UserDefaults
    private func loadReminders(for date: Date) { 
        let dateKey = formattedDate(for: date)
        reminders = UserDefaults.standard.stringArray(forKey: dateKey) ?? []
    }
    
    // Formats the selected date as a string key for UserDefaults (Year-Month-Day)
    private func formattedDate(for date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.timeZone = TimeZone(secondsFromGMT: 0) // Consistent timezone
        return formatter.string(from: date)
    }
}

struct CalendarView_Previews: PreviewProvider {
    static var previews: some View {
        CalendarView()
    }
}
