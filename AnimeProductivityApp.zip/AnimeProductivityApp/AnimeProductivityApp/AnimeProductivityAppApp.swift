//
//  AnimeProductivityAppApp.swift
//  AnimeProductivityApp
//
//  Created by Sudowe, Yuki - Student on 10/24/24.
//

import SwiftUI

@main
struct AnimeProductivityAppApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
